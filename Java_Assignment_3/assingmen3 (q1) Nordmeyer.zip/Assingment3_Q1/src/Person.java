
public class Person {
    // Instance variables
    private String name;
    private int age;
    private Car car;

    // Constructor
    public Person(String name, int age, Car car) {
        this.name = name;
        this.age = age;
        this.car = car;
    }

    // Method to return information about the person
    public String getInfo() {
        return "Person name: " + name + ", age: " + age + ", drives a " + car.getInfo();
    }
}