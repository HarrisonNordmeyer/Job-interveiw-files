
public class DistanceConverter {

    public double toKilometers(double meters) {
        return meters / 1000;
    }

    public double toCentimeters(double meters) {
        return meters * 100;
    }
    
    public double toMillimeters(double meters) {
        return meters * 1000;
    }
}