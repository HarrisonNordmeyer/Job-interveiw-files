
public class Book {
	 private String title;
	    private String author;
	    private int yearpublished;

	    
	 public Book(String title, String author, int yearpublished) {
	     this.title = title;
	     this.author = author;
	     this.yearpublished = yearpublished;
	   }
	    public Book(String title, String author) {
	        this.title = title;
	        this.author = author;
	        this.yearpublished = 0;
	    }
	    public Book(String title) {
	        this.title = title;
	        this.author = "Unknown";
	        this.yearpublished = 0; 
	    }
	    public void displayBookDetails() {
	        System.out.println("Title: " + title);
	        System.out.println("Author: " + author);
	        System.out.println("Year Published: " + (yearpublished == 0 ? "Not specified" : yearpublished));
	    }
}